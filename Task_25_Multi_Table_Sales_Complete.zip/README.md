
# Veda Technology - Task 25
# Multi-Table Sales Analysis

## Objective

Combine orders, products and customers for business analysis
using SQL relational joins and aggregation.

## Technologies

- Python
- Pandas
- NumPy
- SQLite
- SQL
- Plotly
- Excel
- Google Colab
- Power BI

## Tables

1. Customers
2. Products
3. Orders
4. Order Items

## Analysis

- Region-wise sales
- Category-wise sales
- Product-wise sales
- Monthly sales
- Customer sales
- Order-level sales
- Relational joins
- Double-counting validation

## KPIs

Total Sales: ₹11,512,900.00

Total Orders: 150

Customers: 30

Products: 12

Units Sold: 889

Average Order Value: ₹76,752.67

## Dashboard

The project includes an interactive HTML dashboard with:

- Region filter
- Category filter
- KPI cards
- Region sales chart
- Category sales chart
- Product sales chart
- Monthly sales trend

## Deliverables

- task25_analysis.sql
- sales_analysis.db
- CSV datasets
- Analysis CSV files
- Excel workbook
- Interactive HTML dashboard
- PDF report
- Business insights
