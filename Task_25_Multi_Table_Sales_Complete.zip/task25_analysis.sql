
-- ==========================================================
-- VEDA TECHNOLOGY
-- TASK 25 - MULTI-TABLE SALES ANALYSIS
-- ==========================================================

-- TABLES
-- customers
-- products
-- orders
-- order_items

-- COMPLETE JOIN

SELECT
    o.OrderID,
    o.OrderDate,
    c.CustomerID,
    c.CustomerName,
    c.Region,
    p.ProductID,
    p.ProductName,
    p.Category,
    oi.Quantity,
    oi.UnitPrice,
    oi.Sales
FROM orders o
JOIN customers c
    ON o.CustomerID = c.CustomerID
JOIN order_items oi
    ON o.OrderID = oi.OrderID
JOIN products p
    ON oi.ProductID = p.ProductID;


-- REGION SALES

SELECT
    c.Region,
    SUM(oi.Sales) AS TotalSales
FROM orders o
JOIN customers c
    ON o.CustomerID = c.CustomerID
JOIN order_items oi
    ON o.OrderID = oi.OrderID
GROUP BY c.Region
ORDER BY TotalSales DESC;


-- CATEGORY SALES

SELECT
    p.Category,
    SUM(oi.Sales) AS TotalSales
FROM order_items oi
JOIN products p
    ON oi.ProductID = p.ProductID
GROUP BY p.Category
ORDER BY TotalSales DESC;


-- PRODUCT SALES

SELECT
    p.ProductName,
    p.Category,
    SUM(oi.Quantity) AS UnitsSold,
    SUM(oi.Sales) AS TotalSales
FROM order_items oi
JOIN products p
    ON oi.ProductID = p.ProductID
GROUP BY p.ProductID, p.ProductName, p.Category
ORDER BY TotalSales DESC;


-- MONTHLY SALES

SELECT
    strftime('%Y-%m', o.OrderDate) AS Month,
    SUM(oi.Sales) AS TotalSales
FROM orders o
JOIN order_items oi
    ON o.OrderID = oi.OrderID
GROUP BY Month
ORDER BY Month;


-- CUSTOMER SALES

SELECT
    c.CustomerID,
    c.CustomerName,
    c.Region,
    COUNT(DISTINCT o.OrderID) AS OrdersCount,
    SUM(oi.Sales) AS TotalSales
FROM customers c
JOIN orders o
    ON c.CustomerID = o.CustomerID
JOIN order_items oi
    ON o.OrderID = oi.OrderID
GROUP BY
    c.CustomerID,
    c.CustomerName,
    c.Region
ORDER BY TotalSales DESC;


-- ORDER LEVEL SALES

SELECT
    o.OrderID,
    o.OrderDate,
    c.Region,
    SUM(oi.Sales) AS OrderSales
FROM orders o
JOIN customers c
    ON o.CustomerID = c.CustomerID
JOIN order_items oi
    ON o.OrderID = oi.OrderID
GROUP BY
    o.OrderID,
    o.OrderDate,
    c.Region;

